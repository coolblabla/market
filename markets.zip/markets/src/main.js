// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
 //import Vuerify from 'vuerify'
import 'lib-flexible'
import fastclick from 'fastclick'
import './common/stylus/index.styl'
import {isIos,isAndroid} from "./common/js/verify"
// import wcSwiper from 'wc-swiper'
// import 'wc-swiper/style.css'
// Vue.use(wcSwiper);
//import {auth,userInfo} from "./api/api"
//import {bus} from "./common/js/bus"
//import VueClipboard  from 'vue-clipboard2'
fastclick.attach(document.body);
//Vue.use(Vuerify);
//Vue.use(VueClipboard);

Vue.config.productionTip = false;



router.beforeEach((to,from,next) =>{
  if (to.matched.some(record => record.meta.requiresAuth)) {  //meta 路由元信息判断
    if (isIos()){
   //   next();    //到时候要取消掉
     if( typeof(localStorage.ioscon) == 'string'){
       var iosParams = JSON.parse(localStorage.ioscon);
        localStorage.$rem = iosParams.userid;    //获取用户id
        if (iosParams.islogin == 1){
           next();
        }else if(iosParams.islogin == 0){
          window.webkit.messageHandlers.getParam.postMessage('');
          // window.location.href = 'http://www.taobao.com'
        }
     }else {
       alert('格式错误')
     }
    }

    if (isAndroid()){
     // next();    //到时候要取消掉
     var  result =  window.android.getParam();
      localStorage.result = result;
      result = result.split(",");
      localStorage.$rem = result[1];   //获取用户id
      if (result[0] == 'true'){
         next();
      }else if (result[0] == 'false'){  //没有登录
     //   window.android.toLogin();
      }
    }


  } else {
    next()
  }
});


new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
});

