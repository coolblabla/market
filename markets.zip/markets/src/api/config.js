export const options = {
   proUrl:'http://47.98.245.177',
   locationUrl:'10.10.100.11',
  // url:'http://10.10.100.35:8181',
   url :'http://10.10.100.21:18080'
};
export const params =  {
  source :'wap',
  limit:20,
  merchantcode:'aMz475',
  adminCode :'330100',

};
export const baseConfig = {
  responseCode:1000
}



  // [
  // {
  //   "linkUrl": "https://c.y.qq.com/node/m/client/music_headline/index.html?_hidehd=1&_button=2&zid=700567",
  //   "picUrl": "http://y.gtimg.cn/music/photo_new/T003R720x288M000003kGTF00E6oXe.jpg",
  //   "id": 15055,
  //   "name":"老张有钱,",
  //   "min":"1000",
  //   "max":"20000",
  //   list:['身份证','一次还清','新上线1']
  // },
  //   {
  //     "linkUrl": "https://y.qq.com/msa/319/5_5136.html",
  //     "picUrl": "http://y.gtimg.cn/music/photo_new/T003R720x288M0000008Xxwd1417y8.jpg",
  //     "id": 15068,
  //     "name":"我曾经很有钱,只是用完了",
  //     "min":"1000",
  //     "max":"8000",
  //     list:['身份证','一次还清','新上线2']
  //   },
  //   {
  //     "linkUrl": "https://y.qq.com/msa/324/0_5137.html",
  //     "picUrl": "http://y.gtimg.cn/music/photo_new/T003R720x288M000002ab5of4Z6qH0.jpg",
  //     "id": 14616,
  //     "name":"喝喝",
  //     "min":"1000",
  //     "max":"5000",
  //     list:['身份证','一次还清','新上线3']
  //   }
  // ];
