<template>
  <div class="continue">

    <search>
      <div class="address">
          <router-link to="/local">
            <i></i>
             <span>{{cityName}}</span>
          </router-link>
      </div>
    </search>
    <div class="productWrap" ref="productWrap">
      <div>
        <div class="top-tip">
          <span class="refresh-hook">{{topTip}}</span>
        </div>
        <div class="refreshAlert" v-show="refreshAlert"><p>刷新成功!</p></div>
        <div class="bannerWrap">
          <div class="banner">
            <swiper :flag="'bannerSwiper'" :autoplay="5000" :dom="'bannerContainer'" :pagination="'banner-pagination'" ref="banner">
                <div slot="slider" class="swiper-slide" v-for="(item,key) in banner" :key="key">
                  <a :href="item.vUrl" >
                    <img :src="item.vImgUrl"  width="100%" height="100%"/>
                  </a>
                </div>
               <div slot="pagination" class="banner-pagination" id="banner-pagination"></div>
            </swiper>
          </div>
          <div class="bannerTab">
            <swiper :flag="'tabSwiper'" :autoplay="4000" :dom="'tabContainer'" :pagination="'tab-pagination'" ref="tab">
              <div  slot="slider" class="swiper-slide tabSlider" v-for="(item, key) in tabList" :key="key">
                <ul>
                  <li v-for="(slider,index) in item" :key="index" >
                    <router-link :to="{name:'tab'+(index+1),params:{tabId:index+1,id:slider.id}}">
                      <i :class="'tabIcon'+slider.id"></i>
                      <p>{{slider.id}}{{slider.typeName}}</p>
                    </router-link>
                  </li>
                </ul>
              </div>
              <div slot="pagination" class="tab-pagination" id="tab-pagination"></div>
            </swiper>
          </div>
        </div>
        <!--借贷精选-->
        <proGood>
          <div class="head" slot="head">
            <list-title :title="'借贷精选'" :more="true" :skip="'tab0'" :routerparams = routerparams></list-title>
          </div>
          <div class="proGood_list" slot="main">
            <swiper :flag="'proGoodSwiper'" :autoplay="3000" :dom="'proGoodContainer'" :pagination="'proGood-pagination'" ref="proGood">
              <div  slot="slider" class="swiper-slide goodSlider" v-for="(item, key) in goodProList" :key="key">
                <ul>
                  <li v-for="(slider,key2) in item" :key="key2">
                    <router-link :to="{name:'applyPage'}">
                      <img :src="slider.proIcon" />
                      <p>{{slider.proName}}</p>
                    </router-link>
                  </li>
                </ul>
              </div>
              <div slot="pagination" class="proGood-pagination" id="proGood-pagination"></div>
            </swiper>
          </div>
        </proGood>
        <!-- 热门推荐 -->
        <div class="hot">
          <div class="head">
            <list-title :title="'热门推荐'"></list-title>
          </div>
          <div class="list">
            <hot :arr="recommends"></hot>
          </div>
        </div>
        <div class="bottom-tip" v-show="bottomTipJudge">
          <span class="loading-hook">{{bottomTip}}</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import 'swiper/dist/css/swiper.min.css'
  import Swiper from 'swiper'
  import BScroll from 'better-scroll'
  import search from '../common/search.vue'
  import listTitle from '../common/listTitle.vue'
  import swiper from '../common/swiper.vue'
  import proGood from '../common/proGood.vue'
  import hot from '../common/hot.vue'
  import {banner,hotProduct,selectProduct} from '../../api/api'
  import {ProductTypes} from '../../api/cityApi'
  import {initScroll,initAxios,swiperConfig,excision} from '../../common/js/fun'
  import {bus} from '../../common/js/bus'
  import {params} from '../../api/config'
  export default {
    data(){
      return {
        /*刷新和加载跟多一些数据*/
        topTip:'下拉刷新',
        bottomTip:'查看更多',
        bottomTipJudge:false,
        refreshAlert:false,
        page :1,
        banner:[],  //轮播图
        tabList:[],
        goodProList:[],  //产品精选
        recommends:[],
        cityName:bus.city,
        routerparams:{
          tabId:0,
        },
        slider:{
          banner:'bannerSwiper'
        }
      }
    },
    created(){
      this.$router.typeId = 2; //区分 同城 和 线上
      this.initBanner();
      this.initProType();
      this.initGoodPro();



      this.$nextTick(() =>{
        initScroll(this,hotProduct,this.$refs.productWrap,{page:this.page,isLine:2});
      });

    },
    methods:{
      initBanner(){
        initAxios(banner,{state:2},(res) =>{  //banner 轮播图
          this.banner = res.list;
          this.$nextTick(() =>{
            this.$refs.banner.init()
          })
        });
      },
      initProType(){
        /*tab  type  借款类型*/
        initAxios(ProductTypes,{typeId:2},(res) =>{ //产品精选  这里要城市code
          this.tabList = excision(res.list,5);
          this.$nextTick(() =>{
            this.$refs.tab.init()
          });
        });
      },
      initGoodPro(){
        initAxios(selectProduct,{isLine:2,adminCode:330200},(res) =>{ //产品精选  这里要城市code
          this.goodProList = excision(res.list,4);
          this.$nextTick(() =>{
            this.$refs.proGood.init()
          });
        });
      }
    },
    mounted(){
       bus.$on('address',(res) =>{
        this.cityName = res;
      });
      bus.$on('refreshcity',res=>{
        this.$refs.tab.destroy();
        this.initProType();
        this.$refs.proGood.destroy();
        this.initGoodPro();

      });
    },
    activated(){
      if( this.$refs.banner.isActive){
        this.$refs.banner.destroy();
        this.$refs.banner.init();
      }
      if( this.$refs.tab.isActive){
        this.$refs.tab.destroy();
        this.$refs.tab.init();
      }
      if( this.$refs.proGood.isActive){
        this.$refs.proGood.destroy();
        this.$refs.proGood.init();
      }
    },
    components:{search,swiper,listTitle,hot,proGood}
  }
</script>
<style scoped lang="stylus">
  @import "../../common/stylus/variable.styl"
  @import "../../common/stylus/mixin.styl"
  @import "../../common/stylus/proList.styl"
  .continue
    .bannerWrap
      background-color #ffffff
      padding-top 20px
      overflow hidden
      .banner
        height 200px
        a
          height @height
      .bannerTab
        width 100%
        height 213px
        .tabSlider
          padding 22px 20px 0 20px
          box-sizing border-box
          ul
            display flex
            justify-content space-between
            margin auto
            li
              margin auto
              a
                display block
                width 100%
                height 100%
                text-align center
                i
                  display block
                  width 90px
                  height 90px
                  margin 0 auto
                  margin-bottom 12px
                .tabIcon9
                  $bg-image('./img/ic-tcd-cd')
                  $bg-size(100%,100%)
                .tabIcon10
                  $bg-image('./img/ic-tcd-fd')
                  $bg-size(100%,100%)
                .tabIcon11
                  $bg-image('./img/ic-tcd-bdd')
                  $bg-size(100%,100%)
                .tabIcon12
                  $bg-image('./img/ic-tcd-zjd')
                  $bg-size(100%,100%)
                .tabIcon13
                  $bg-image('./img/ic-tcd-lsd')
                  $bg-size(100%,100%)
                .tabIcon14
                  $bg-image('./img/ic-tcd-qyd')
                  $bg-size(100%,100%)
                p
                  font-size $font-size-24
                  color $color-black
    .hot
      background-color #ffffff
      .head
        padding-left 40px
      .list
        padding-left 40px
  .productWrap
    position absolute
    left 0
    right 0
    top 88px
    bottom 0
    overflow hidden
  .address
    display flex
    a
      height 44px
      margin auto
      color #ffffff
      font-size $font-size-28
      i
        display inline-block
        vertical-align middle
        width 44px
        height 44px
        $bg-image('./img/ic-addr')
        background-size 100% 100%
      span
        display inline-block
        vertical-align middle
  .top-tip
    position absolute
    top -60px
    text-align center
    left 50%
    transform translate(-50%)
  .refreshAlert
    top 0
  #banner-pagination,#proGood-pagination,#tab-pagination
    position: absolute
    z-index 9
    text-align center
    span
      width 30px
      height 6px
      border-radius 6px
      background-color #ffffff
</style>
<style>
  .swiper-pagination-bullet{
    width: 30px;
    height :6px;
    border-radius: 6px;
    background-color: rgb(55,137,229);
  }
  #proGood-pagination>.swiper-pagination-bullet-active{
    background-color: rgb(55,137,229);
  }
  #tab-pagination>.swiper-pagination-bullet-active{
    background-color: rgb(55,137,229);
  }
</style>
