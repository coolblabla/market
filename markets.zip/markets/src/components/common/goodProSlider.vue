<!-- 极品产品轮播图 -->
<template>

</template>
<script type="text/ecmascript-6">

</script>
<style></style>
