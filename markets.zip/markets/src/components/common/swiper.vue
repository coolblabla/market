<template>
  <div class="swiper-container" style="position: relative" :class="dom">
    <div class="swiper-wrapper">
      <slot name="slider"></slot>
    </div>
    <slot name="pagination"></slot>
  </div>
</template>
<script type="text/ecmascript-6">
  import Swiper from 'swiper';
  import 'swiper/dist/css/swiper.min.css';
  export default {
    props:{
      dom:{
        type:String,
        default(){
          return 'swiperWrap'
        }
      },
      loop:{
        type:Boolean,
        default(){
          return true
        }
      },
      speed:{
        type:Number,
        default(){
          return 600
        }
      },
      pagination:{
        default(){
          return 'swiper-pagination'
        }
      },
      autoplay:{
        default(){
          return 3000
        }
      },
      flag:{
        default() {
          return 'swiper'
        }
      }
    },
    data(){
      return {
        isActive : false
      }
    },
    deactivated(){
      this.isActive = true;
    },
    methods:{
      init(){
        this[this.flag] = new Swiper('.'+this.dom, {
          pagination: '.'+this.pagination,
          loop: this.loop,
          speed: this.speed,
          autoplay: this.autoplay,
          autoplayDisableOnInteraction:false,
          observer: true,
          observeParents:true,
        });
      },
      destroy(){
        this[this.flag].destroy(true);
      },
      refresh(){
        this[this.flag].reLoop();
      }
    }
  }
</script>
<style lang="stylus" scoped>
  .swiper-container
    height 100%
</style>
