


import Vue from 'vue'
import App from './CityLoan.vue'
import router from './router/indexCity'
//import Vuerify from 'vuerify'
import 'lib-flexible'
import fastclick from 'fastclick'
import './common/stylus/index.styl'
import {isIos,isAndroid} from "./common/js/verify"
import {bus} from "./common/js/bus"
 import {getLocation} from './common/js/address'
//import {auth,userInfo} from "./api/api"
//import VueClipboard  from 'vue-clipboard2'
fastclick.attach(document.body);
//Vue.use(Vuerify);
//Vue.use(VueClipboard);
Vue.config.productionTip = false;



router.beforeEach((to,from,next) =>{
  bus.$on('address-component',(data)=>{
    if (to.matched.some(record => record.meta.requiresAuth)) {  //meta 路由元信息判断
      if (isIos()){
        next();    //到时候要取消掉
        if( typeof(localStorage.ioscon) == 'string'){
          var iosParams = JSON.parse(localStorage.ioscon);
          localStorage.$iosrem = iosParams.userid;    //获取用户id
          if (iosParams.islogin == 1){
            next();
          }else if(iosParams.islogin == 0){
            window.webkit.messageHandlers.getParam.postMessage('');
            // window.location.href = 'http://www.taobao.com'
          }
        }else {
          alert('格式错误')
        }
      }

      if (isAndroid()){
        next();    //到时候要取消掉

        var  result =  window.android.getParam();
        localStorage.result = result;
        result = result.split(",");
        localStorage.$androidrem = result[1];
        if (result[0] == 'true'){
          next();
        }else if (result[0] == 'false'){  //没有登录
          //   window.android.toLogin();
        }
      }


    } else {
      next() // 确保一定要调用 next()
    }
  });
   if (bus.entryPage){
    if (to.matched.some(record => record.meta.requiresAuth)) {  //meta 路由元信息判断
      if (isIos()){
        next();    //到时候要取消掉
        if( typeof(localStorage.ioscon) == 'string'){
          var iosParams = JSON.parse(localStorage.ioscon);
          localStorage.$iosrem = iosParams.userid;    //获取用户id
          if (iosParams.islogin == 1){
            next();
          }else if(iosParams.islogin == 0){
            window.webkit.messageHandlers.getParam.postMessage('');
            // window.location.href = 'http://www.taobao.com'
          }
        }else {
          alert('格式错误')
        }
      }

      if (isAndroid()){
        next();    //到时候要取消掉

        var  result =  window.android.getParam();
        localStorage.result = result;
        result = result.split(",");
        localStorage.$androidrem = result[1];
        if (result[0] == 'true'){
          next();
        }else if (result[0] == 'false'){  //没有登录
          //   window.android.toLogin();
        }
      }


    } else {
      next() // 确保一定要调用 next()
    }
  }

});


new Vue({
  el: '#app',
  router,
  components: { App },
  data(){
    return {
      cityAddress:''
    }
  },
  created(){
    getLocation()
  },
  template: '<App/>'
});

